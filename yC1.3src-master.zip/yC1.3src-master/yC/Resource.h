//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by yC.rc
//
#define IDC_MYICON                      2
#define IDD_YC_DIALOG                   102
#define IDD_MAINDLG                     102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_YC                          109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       132
#define IDI_ICON                        132
#define IDC_FILENAME                    1000
#define IDC_TARGETFILE                  1000
#define IDC_EDIT1                       1000
#define IDC_CHOOSEFILE                  1001
#define IDC_CRYPT                       1003
#define IDC_PROGRESS1                   1007
#define IDC_ABOUT                       1009
#define IDC_SICHECK                     2001
#define IDC_ERASEPEHEADER               2002
#define IDC_DESTROYIMPORT               2003
#define IDC_ANTIDUMP                    2005
#define IDC_APIREDIRECT                 2006
#define IDC_CHECKHEADERCRC              2008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
