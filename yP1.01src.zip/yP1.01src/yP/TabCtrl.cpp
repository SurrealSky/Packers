/* TabCtrl.cpp --

   This file is part of the "yoda's Protector".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   yoda's Protector library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/

#include "stdafx.h"
#include "yP.h"
#include "TabCtrl.h"
#include "TrackCtrl.h"
#include "CryptStuff.h"
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <winuser.h>


char cFname[256];
char cFnameOpen[256];
char cFnameSave[256];
char cExecute[256];

HIMAGELIST hImageList;
BOOL fStatus;
OPENFILENAME ofn;
char szCurDir[]=".";
char szFilter[]="EXE files (*.exe)|*.exe|All files (*.*)|*.*||";

DWORD dwProtectFlags	= 0x3D;
DWORD dwAdvancedFlags	= 0x13;
DWORD dwCompressLevel	=	9;
CHAR lpszSectionName[16]; 

int iSectionName=2;

bool CheckSI		= TRUE;
bool DestroyImport	= TRUE;
bool CheckCRC		= TRUE;
bool AntiDump		= TRUE;
bool ApiRedirect	= TRUE;
bool CompressRsrc	= FALSE;
bool EraseHeader	= FALSE;

bool RemoveReloc	= TRUE;
bool RemoveDebug	= TRUE;
bool RemoveDOS		= FALSE;
bool OptmizeDOS		= FALSE;

bool MakeBackUp		= TRUE;
bool AutoRun		= FALSE;
bool ExitWhenDone	= FALSE;


HWND WINAPI OnTabbedDialogInit(HWND hwndDlg);
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName);
HWND WINAPI OnSelChanged(HWND hwndDlg);
VOID WINAPI OnChildDialogInit(HWND hwndDlg);
LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

// AddIconsToImageList - creates a masked image list and adds some 
// icons to it. 
// Returns the handle to the new image list. 
// hinst - handle to the application instance. 
// 
// Global variables and constants 
//     g_nBird and g_nTree - indexes of the images. 
//     cx_icon and cy_icon - width and height of the icon. 
//     num_icons - number of icons to add to the image list. 
#define NUM_ICONS 2
#define CX_ICON  16 
#define CY_ICON  16 
HIMAGELIST AddIconsToImageList() 
{ 
    HIMAGELIST himlIcons;  // handle to new image list 
    HICON hicon;           // handle to icon 
 
    // Ensure that the common control DLL is loaded. 
    InitCommonControls(); 

    // Create a masked image list large enough to hold the icons. 
    himlIcons = ImageList_Create(CX_ICON, CY_ICON, ILC_MASK, NUM_ICONS, 0); 
 
    // Load the icon resources, and add the icons to the image list. 
    hicon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_SECUR));
    ImageList_AddIcon(himlIcons, hicon);
	hicon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_OPTION));
	ImageList_AddIcon(himlIcons, hicon);
	//hicon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_OPEN));
	//ImageList_AddIcon(himlIcons, hicon);
	//ImageList_AddIcon(himlIcons, hicon); 
 
    return himlIcons; 
} 

#define C_PAGES 2
const LPSTR szTabName[C_PAGES]=
{
	"Protect",
	"Options",
};
 typedef struct tag_dlghdr { 
    HWND hwndTab;       // tab control 
    HWND hwndDisplay;   // current child dialog box 
    RECT rcDisplay;     // display rectangle for the tab control 
    DLGTEMPLATE *apRes[C_PAGES]; 
} DLGHDR; 
DLGHDR *pHdr;

HWND WINAPI OnTabbedDialogInit(HWND hwndDlg) 
{ 
	RECT rcClient; 
    pHdr = (DLGHDR *) LocalAlloc(LPTR, sizeof(DLGHDR)); 
    TCITEM tie; 
    RECT rcTab; 
    int i; 
	// Save a pointer to the DLGHDR structure. 

    SetWindowLong(hwndDlg, GWL_USERDATA, (LONG) pHdr); 
	
	// Initialize the tab control.
	//InitCommonControls();
	pHdr->hwndTab = GetDlgItem(hwndDlg, IDC_TABS); 
	if (pHdr->hwndTab == NULL)// handle error 
	{
        return NULL;
    }
    // Determine the bounding rectangle for all child dialog boxes. 
	SetRectEmpty(&rcTab);
	GetClientRect(pHdr->hwndTab, &rcTab); 
	GetClientRect(hwndDlg, &rcClient); 
	rcTab.top=rcClient.bottom-rcTab.bottom+8;
	rcTab.left=5;
	rcTab.right=rcTab.right-4;
	rcTab.bottom=rcTab.top+rcTab.bottom-31;

	// Add a tab for each of the three child dialog boxes.
    tie.mask = TCIF_TEXT | TCIF_IMAGE; 

    for (i=0;i<C_PAGES;i++) 
	{ 
        LoadString(hInst, IDC_TABS + i, 
                g_achTemp, sizeof(g_achTemp)/sizeof(g_achTemp[0])); 
		tie.pszText = szTabName[i]; 
		tie.iImage = i;
        if(TabCtrl_InsertItem(pHdr->hwndTab, i, &tie)== -1) 
		{ 
            DestroyWindow(pHdr->hwndTab); 
            return NULL; 
		}
	} 

    // Lock the resources for the three child dialog boxes. 
    pHdr->apRes[0] = DoLockDlgRes(MAKEINTRESOURCE(DLG_PROTECT));
    pHdr->apRes[1] = DoLockDlgRes(MAKEINTRESOURCE(DLG_OPTIONS));
	//pHdr->apRes[2] = DoLockDlgRes(MAKEINTRESOURCE(DLG_PROJECT)); 
	// Calculate the display rectangle. 
    CopyRect(&pHdr->rcDisplay, &rcTab); 

	// Simulate selection of the first item. 
    OnSelChanged(hwndDlg); 

    return pHdr->hwndTab; 
} 

// DoLockDlgRes - loads and locks a dialog template resource. 
// Returns a pointer to the locked resource. 
// lpszResName - name of the resource  
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName) 
{ 
    HRSRC hrsrc = FindResource(NULL, lpszResName, RT_DIALOG); 
    HGLOBAL hglb = LoadResource(hInst, hrsrc); 

    return (DLGTEMPLATE *) LockResource(hglb); 
} 

// OnSelChanged - processes the TCN_SELCHANGE notification. 
// hwndDlg - handle to the parent dialog box. 
HWND WINAPI OnSelChanged(HWND hwndDlg) 
{ 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong(hwndDlg, GWL_USERDATA);
    int iSel = TabCtrl_GetCurSel(pHdr->hwndTab); 
 
    // Destroy the current child dial!og box, if any. 
    if (pHdr->hwndDisplay != NULL) 
        DestroyWindow(pHdr->hwndDisplay); 
 
    // Create the new child dialog box. 
	pHdr->hwndDisplay = CreateDialogIndirect(hInst, 
        pHdr->apRes[iSel], hwndDlg,(DLGPROC) ChildDialogProc);
	return(pHdr->hwndDisplay);
} 
 
// OnChildDialogInit - Positions the child dialog box to fall 
//     within the display area of the tab control. 
 VOID WINAPI OnChildDialogInit(HWND hwndDlg) 
{ 
    HWND hwndParent = GetParent(hwndDlg); 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong( 
        hwndParent, GWL_USERDATA); 
    SetWindowPos(hwndDlg, HWND_TOP, 
		pHdr->rcDisplay.left, 
		pHdr->rcDisplay.top, 
		pHdr->rcDisplay.right-pHdr->rcDisplay.left, 
		pHdr->rcDisplay.bottom-pHdr->rcDisplay.top, 
		SWP_DRAWFRAME); 
}

VOID UpdateFlags()
{
	// ---- build the protection flag -----
	dwProtectFlags=0;
	//IsDlgButtonChecked(hDlg,IDC_APIREDIRECT)== BST_CHECKED
	if(CheckSI)			dwProtectFlags=dwProtectFlags|CHECK_SI_FLAG;
	if(DestroyImport)	dwProtectFlags=dwProtectFlags|DESTROY_IMPORT_FLAG;
	if(CheckCRC)		dwProtectFlags=dwProtectFlags|CHECK_HEADER_CRC;
	if(AntiDump)		dwProtectFlags=dwProtectFlags|ANTI_DUMP_FLAG;
	if(ApiRedirect)		dwProtectFlags=dwProtectFlags|API_REDIRECT_FLAG;
	if(EraseHeader)		dwProtectFlags=dwProtectFlags|ERASE_HEADER_FLAG;
	if(CompressRsrc)	dwProtectFlags=dwProtectFlags|COMPRESS_RSRC_FLAG;

	dwAdvancedFlags=0;
	if(RemoveReloc)		dwAdvancedFlags=dwAdvancedFlags|REMOVE_RELOC;
	if(RemoveDebug)		dwAdvancedFlags=dwAdvancedFlags|REMOVE_DEBUG;
	if(RemoveDOS)		dwAdvancedFlags=dwAdvancedFlags|REMOVE_DOS_HEADER;
	if(OptmizeDOS)		dwAdvancedFlags=dwAdvancedFlags|OPTIMIZED_DOS_HEADER;

	if(MakeBackUp)		dwAdvancedFlags=dwAdvancedFlags|CREATE_BACKUP;
	if(AutoRun)			dwAdvancedFlags=dwAdvancedFlags|AUTO_RUN;
	if(ExitWhenDone)	dwAdvancedFlags=dwAdvancedFlags|EXIT_WHEN_DONE;
	SaveToRegistry(dwProtectFlags,
				   dwAdvancedFlags,
				   dwCompressLevel,
				   lpszSectionName);
}


LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT wmId, wmEvent;
	switch (message)
	{
	case WM_INITDIALOG:
		OnChildDialogInit(hDlg);
		// check the checkboxes :)
		SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
		strcpy(cFnameSave,cFnameOpen);
		SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);

		if(CheckSI)		 CheckDlgButton(hDlg,IDC_SICHECK,TRUE);
		if(EraseHeader)	 CheckDlgButton(hDlg,IDC_ERASEPEHEADER,TRUE);
		if(DestroyImport)CheckDlgButton(hDlg,IDC_DESTROYIMPORT,TRUE);
		if(CheckCRC)  CheckDlgButton(hDlg,IDC_CHECKHEADERCRC,TRUE);
		if(AntiDump)	 CheckDlgButton(hDlg,IDC_ANTIDUMP,TRUE);
		if(ApiRedirect)	 CheckDlgButton(hDlg,IDC_APIREDIRECT,TRUE);

		if(RemoveReloc)	CheckDlgButton(hDlg,IDC_REMOVERELOC,TRUE);
		if(RemoveDebug)	CheckDlgButton(hDlg,IDC_RMDEBUG,TRUE);
		if(RemoveDOS)CheckDlgButton(hDlg,IDC_REMOVEDOS,TRUE);
		if(OptmizeDOS)	CheckDlgButton(hDlg,IDC_OPTIMIZEDOS,TRUE);
		hButton=GetDlgItem(hDlg,IDC_OPTIMIZEDOS); 
		if(RemoveDOS)EnableWindow(hButton,FALSE);
		else EnableWindow(hButton,TRUE);

		if(MakeBackUp)	CheckDlgButton(hDlg,IDC_MAKEBACKUP,TRUE);
		if(AutoRun)		CheckDlgButton(hDlg,IDC_AUTORUN,TRUE);
		if(ExitWhenDone)CheckDlgButton(hDlg,IDC_EXITDONE,TRUE);

		DragAcceptFiles(hDlg,TRUE);
		SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
		SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
		if(cFnameSave[0]!=0x00)
		{
			hButton=GetDlgItem(hDlg,ID_FILE_SAVE); 
			EnableWindow(hButton,TRUE);
			hButton=GetDlgItem(hDlg,ID_FILE_PROTECT); 
			EnableWindow(hButton,TRUE);
			hButton=GetDlgItem(hDlg,IDC_STATIC2); 
			EnableWindow(hButton,TRUE);
			UpdateWindow(hDlg); 
			EnableMenuItem(hMenu,ID_FILE_SAVE,MF_ENABLED);
			EnableMenuItem(hMenu,ID_FILE_PROTECT,MF_ENABLED);
			UpdateWindow(hwndMain);
		}
		hImageList=AddIconsToImageList();
		TabCtrl_SetImageList(hwndTab,hImageList);
		SetDlgItemInt(hDlg,IDC_COMPRESSRATE,dwCompressLevel,FALSE);
		SetDlgItemText(hDlg,IDC_SECTIONNAME,lpszSectionName);
		SendDlgItemMessage(hDlg,
			               IDC_SECTIONNAME,
						   EM_SETLIMITTEXT,8, 0);
		/*CreateTrackbar(hwndDisplay,
				iMinTrack,iMaxTrack,
				iMinTrack,iMaxTrack,
				iPageSizeTrack);*/
		return TRUE;

	case WM_DROPFILES:
		HDROP	hDrop;
		hDrop=HDROP(wParam);
		DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
		DragFinish(hDrop);
		SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
		strcpy(cFnameSave,cFnameOpen);
		SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
		SendMessage(hDlg, WM_INITDIALOG, 0, 0);
		break;

	case WM_HSCROLL:
		TBNotifications(wParam,hwndTrack);
		SetDlgItemInt(hDlg,IDC_COMPRESSRATE,dwCompressLevel,FALSE);
		break;

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDC_SECTIONNAME:
			switch(wmEvent)
			{
			case EN_CHANGE:
				iSectionName = (WORD) SendDlgItemMessage(hDlg, 
								IDC_SECTIONNAME, 
								EM_LINELENGTH, 
								(WPARAM) 0, 
								(LPARAM) 0); 
				*((LPWORD)lpszSectionName) = iSectionName; 
				SendDlgItemMessage(hDlg, 
                               IDC_SECTIONNAME, 
                               EM_GETLINE, 
                               (WPARAM) 0,       // line 0 
                               (LPARAM)lpszSectionName);
				lpszSectionName[iSectionName] = 0; 
				break;
			}
			break;
		case ID_FILE_OPEN:
			// get a file path
 			cFname[0]=0x00;
			ZeroMemory(&ofn, sizeof(ofn));
			ofn.hwndOwner=GetActiveWindow();
			ofn.lpstrFile=cFname;
			ofn.nMaxFile=sizeof(cFname);
			ofn.lStructSize=sizeof(ofn);
			ofn.lpstrFilter=TEXT("EXE files (*.exe)\0*.exe;All files (*.*)\0*.*\0\0");
			ofn.nFilterIndex = 1; 
			//ofn.lpstrInitialDir=szCurDir;
			ofn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			fStatus =GetOpenFileName(&ofn);//(LPOPENFILENAME
			if(!fStatus)
			{
				return 0;
			}
			strcpy(cFnameOpen,cFname);
			SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
			strcpy(cFnameSave,cFnameOpen);
			SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
			SendMessage(hDlg, WM_INITDIALOG, 0, 0);
			if(AutoRun)
			{
				SendMessage(hDlg,WM_COMMAND,ID_FILE_PROTECT, 0);
			}
			break;

		case ID_FILE_SAVE:
			// get a file path
			cFnameSave[0]=0x00;
			strcpy(cFnameSave,cFnameOpen);
			ZeroMemory(&ofn, sizeof(ofn));
			ofn.hwndOwner=GetActiveWindow();
			ofn.lpstrFile=cFnameSave;
			ofn.nMaxFile=sizeof(cFnameSave);
			ofn.lStructSize=sizeof(ofn);
			ofn.lpstrFilter=TEXT("EXE files (*.exe)\0*.exe;All files (*.*)\0*.*\0\0");
			ofn.nFilterIndex = 1; 
			//ofn.lpstrInitialDir=szCurDir;
			ofn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			fStatus =GetSaveFileName(&ofn);//(LPOPENFILENAME
			if(!fStatus)
			{
				return 0;
			}
			SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
			break;

		case ID_FILE_PROTECT:
			// ----- was a file selected ? -----
			if(cFnameOpen==NULL)
			{
				MessageBox(hDlg,"No file selected up to now !","ERROR",MB_ICONERROR);
				return 0;
			}
			if(cFnameSave==NULL)
			{
				MessageBox(hDlg,"No file selected up to save !","ERROR",MB_ICONERROR);
				return 0;
			}
			UpdateFlags();
			CryptFile(cFnameOpen,cFnameSave,dwProtectFlags,
					  dwAdvancedFlags,dwCompressLevel,
					  lpszSectionName);
			if(ExitWhenDone)
			{
				PostQuitMessage(0);
			}
			hButton=GetDlgItem(hDlg,ID_FILE_TEST); 
			EnableWindow(hButton,TRUE);
			break;

		case ID_FILE_TEST:
			SaveToRegistry(dwProtectFlags,
						   dwAdvancedFlags,
						   dwCompressLevel,
						   lpszSectionName);
			strcpy(cExecute,"yP.EXE");
			strcat(cExecute," -O ");
			strcat(cExecute,cFnameOpen);
			WinExec(cExecute,SW_SHOW);
			WinExec(cFnameSave,SW_SHOW);
			break;

		case IDC_SICHECK:
			CheckSI=!CheckSI;
			UpdateFlags();
			break;

		case IDC_ERASEPEHEADER:
			EraseHeader=!EraseHeader;
			if(EraseHeader)
			{
				MessageBox(GetActiveWindow(),
					"Be careful, This option does not perform in most PE files.\nIt is possible to corrupt your PE files!",
					"Warning", 
					MB_OK | MB_ICONWARNING);
			}
			UpdateFlags();
			break;

		case IDC_DESTROYIMPORT:
			DestroyImport=!DestroyImport;
			UpdateFlags();
			break;

		case IDC_ANTIDUMP:
			AntiDump=!AntiDump;
			UpdateFlags();
			break;

		case IDC_APIREDIRECT:
			ApiRedirect=!ApiRedirect;
			UpdateFlags();
			break;

		case IDC_CHECKHEADERCRC:
			CheckCRC=!CheckCRC;
			UpdateFlags();
			break;

		case IDC_REMOVERELOC:
			RemoveReloc=!RemoveReloc;
			UpdateFlags();
			break;

		case IDC_RMDEBUG:
			RemoveDebug=!RemoveDebug;
			UpdateFlags();
			break;
		
		case IDC_REMOVEDOS:
			RemoveDOS=!RemoveDOS;
			hButton=GetDlgItem(hDlg,IDC_OPTIMIZEDOS); 
			if(RemoveDOS)EnableWindow(hButton,FALSE);
			else EnableWindow(hButton,TRUE);
			UpdateFlags();
			break;

		case IDC_OPTIMIZEDOS:
			OptmizeDOS=!OptmizeDOS;
			UpdateFlags();
			break;
		
		case IDC_MAKEBACKUP:
			MakeBackUp=!MakeBackUp;
			UpdateFlags();
			break;

		case IDC_AUTORUN:
			AutoRun=!AutoRun;
			UpdateFlags();
			break;

		case IDC_EXITDONE:
			ExitWhenDone=!ExitWhenDone;
			UpdateFlags();
			break;
		}
		break;

	}
	return FALSE;
}
