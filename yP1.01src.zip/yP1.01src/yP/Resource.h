//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by yP.rc
//
#define IDC_MYICON                      2
#define IDD_YC_DIALOG                   102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define DLG_OPTIONS                     106
#define DLG_OPEN                        107
#define DLG_PROTECT                     108
#define DLG_PROJECT                     109
#define IDD_MAINDLG                     110
#define IDD_ABOUTBOX                    111
#define IDC_YP                          112
#define IDR_MAINFRAME                   113
#define IDR_MENU1                       114
#define IDI_ICON                        130
#define IDI_SECUR                       131
#define IDI_OPEN                        132
#define IDI_OPTION                      133
#define IDC_STATIC1                     1000
#define IDC_STATIC2                     1001
#define IDC_FILENAME                    1002
#define IDC_TARGETFILE                  1003
#define IDC_EDIT1                       1004
#define IDC_FILE_OPEN                   1005
#define IDC_FILE_SAVE                   1006
#define IDC_CRYPT                       1007
#define IDC_PROGRESS1                   1008
#define IDC_TABS                        1009
#define IDC_ABOUT                       1010
#define ID_FILE_OPEN                    1011
#define ID_FILE_SAVE                    1012
#define IDC_SECTIONNAME                 1013
#define IDC_LOG                         1014
#define IDC_COMMENT                     1015
#define IDC_COMPRESSLEVEL               1016
#define IDC_MAKEBACKUP                  1017
#define IDC_EXITDONE                    1018
#define IDC_AUTORUN                     1019
#define IDC_REMOVERELOC                 1020
#define IDC_SETNEWALIGN                 1021
#define IDC_COMPRESSSHARED              1022
#define IDC_REMOVEDOS                   1023
#define IDC_OPTIMIZEDOS                 1024
#define IDC_COMPRESSRATE                1025
#define IDC_CHECK1                      1026
#define IDC_RMDEBUG                     1027
#define IDC_WEB                         1028
#define IDC_THANKS                      1029
#define IDC_SICHECK                     1030
#define IDC_ERASEPEHEADER               1031
#define IDC_DESTROYIMPORT               1032
#define IDC_ANTIDUMP                    1033
#define IDC_APIREDIRECT                 1034
#define IDC_CHECKHEADERCRC              1035
#define ID_FILE_PROTECT                 2001
#define ID_HELP_HELPCONTENTS            2002
#define ID_FILE_TEST                    2003
#define ID_HELP_ABOUT                   2004
#define ID_OPTIONS_COMPRESS             2005
#define ID_OPTIONS_PROTECTION           2006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1063
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
