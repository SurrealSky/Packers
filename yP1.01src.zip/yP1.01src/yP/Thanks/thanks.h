#pragma once


/* external gl data */
int WINAPI InitWindow( HINSTANCE hInstance, int nCmdShow );
LRESULT CALLBACK WindowProc( HWND hWnd, UINT uMsg, WPARAM wParam,
                             LPARAM lParam );


