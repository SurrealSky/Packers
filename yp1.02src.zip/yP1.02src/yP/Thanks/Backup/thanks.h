#pragma once


/* external gl data */
extern int width, height;

extern HWND hWnd;

