//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by yP.rc
//
#define IDR_RT_MANIFEST1                1
#define IDC_MYICON                      2
#define IDD_YC_DIALOG                   102
#define IDD_MAINDLG                     102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define DLG_OPTIONS                     107
#define DLG_PROTECTIONOPTIONS           107
#define DLG_OPEN                        108
#define DLG_PROTECT                     108
#define IDC_YC                          109
#define DLG_PROTECTIONOPTIONS1          109
#define DLG_COMPRESSIONOPTIONS          109
#define DLG_ABOUT                       110
#define DLG_PROJECT                     111
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       144
#define IDB_FILENEW                     148
#define IDB_FILEOPEN                    149
#define IDB_OPEN                        149
#define IDB_SAVE                        150
#define IDB_HELP                        151
#define IDB_BITMAP1                     152
#define IDB_PROTECT                     152
#define IDI_ICON1                       154
#define IDI_ICON                        154
#define IDI_SECUR                       155
#define IDI_OPEN                        156
#define IDI_OPTION                      157
#define IDD_ABOUTBOX                    158
#define IDC_FILENAME                    1000
#define IDC_TARGETFILE                  1000
#define IDC_EDIT1                       1000
#define IDC_FILE_OPEN                   1000
#define IDC_FILE_SAVE                   1001
#define IDC_CRYPT                       1003
#define IDC_PROGRESS1                   1007
#define IDC_TABS                        1008
#define IDC_ABOUT                       1009
#define IDC_BNEW                        1015
#define IDC_BUTTON3                     1016
#define IDC_BUTTON4                     1017
#define IDC_BUTTON5                     1018
#define IDC_BPROTECT                    1018
#define IDC_BUTTON6                     1019
#define IDC_BHELP                       1019
#define ID_FILE_OPEN                    1022
#define ID_FILE_SAVE                    1023
#define IDC_STATIC2                     1029
#define IDC_STATIC1                     1030
#define IDC_EDIT2                       1031
#define IDC_SECTIONNAME                 1031
#define IDC_LOG                         1037
#define IDC_COMMENT                     1037
#define IDC_COMPRESSLEVEL               1042
#define IDC_MAKEBACKUP                  1044
#define IDC_EXITDONE                    1045
#define IDC_AUTORUN                     1046
#define IDC_REMOVERELOC                 1047
#define IDC_SETNEWALIGN                 1048
#define IDC_COMPRESSSHARED              1049
#define IDC_REMOVEDOS                   1049
#define IDC_OPTIMIZEDOS                 1051
#define IDC_COMPRESSRATE                1054
#define IDC_CHECK1                      1056
#define IDC_RMDEBUG                     1056
#define IDC_WEB                         1062
#define IDC_THANKS                      1063
#define IDC_STATIC3                     1063
#define IDC_STATIC4                     1064
#define IDC_STATIC5                     1065
#define IDC_STATIC6                     1066
#define IDC_STATIC7                     1067
#define IDC_SICHECK                     2001
#define IDC_ERASEPEHEADER               2002
#define IDC_DESTROYIMPORT               2003
#define IDC_ANTIDUMP                    2005
#define IDC_APIREDIRECT                 2006
#define IDC_CHECKHEADERCRC              2008
#define ID_FILE_PROTECT                 32796
#define ID_HELP_HELPCONTENTS            32798
#define ID_FILE_TEST                    32798
#define ID_HELP_ABOUT                   32799
#define ID_OPTIONS_COMPRESS             32802
#define ID_OPTIONS_PROTECTION           32803
#define ID_VIEW_INTERFACELANGUAGE       32804
#define ID_LNG_ENGLISH                  32814
#define ID_LNG_GERMAN                   32815
#define ID_LNG_FRENCH                   32816
#define ID_LNG_ITALIAN                  32817
#define ID_LNG_SPANISH                  32818
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32819
#define _APS_NEXT_CONTROL_VALUE         1068
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
