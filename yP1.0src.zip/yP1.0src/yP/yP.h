#pragma once

#include "resource.h"

extern	HINSTANCE hInst;// current instance

extern	HWND	hwndMain; 
extern	HMENU	hMenu;
extern	HWND	hwndTab;
extern	HWND	hButton;
extern	HWND	hwndDisplay;
extern	HWND	hwndProgress;

extern char g_achTemp[256];// temporary buffer for strings 