#pragma once

#include "resource.h"

extern char cFnameOpen[256];
extern char cFnameSave[256];

HWND WINAPI OnTabbedDialogInit(HWND hwndDlg);
HWND WINAPI OnSelChanged(HWND hwndDlg) ;
