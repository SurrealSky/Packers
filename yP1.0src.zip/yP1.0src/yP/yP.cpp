/* yS.cpp : Defines the entry point for the application.

   This file is part of the "yoda's Protector v1.0".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   yoda's Protector v1.0 library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/

#include "stdafx.h"
#include "yP.h"
#include "PER.h"
#include "CryptStuff.h"
#include "TabCtrl.h"
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <winuser.h>

// Global Variables:

HINSTANCE hInst;	// current instance


char g_achTemp[256];// temporary buffer for strings 

HDROP	hDrop;
HICON	hIcon;
HBITMAP	hBitmap;
HWND	hButton;


HWND	hwndMain;      // main application window 
HMENU	hMenu;
HACCEL	hAccel;

HWND	hwndTab;	// tab control 
HWND	hwndDisplay;// handle to static control in 
					//   tab control's display area 
HWND	hwndProgress;
// Global variables 



// Forward declarations of functions included in this code module:
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	hInst=GetModuleHandle(0);
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_MAINDLG),0,(DLGPROC)DlgProc,0);
	//DoPropertySheet(hInst);
	ExitProcess(0);
	return (int) msg.wParam;
}


//  FUNCTION: DlgProc(HWND, unsigned, WORD, LONG)
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LRESULT DlgProc(HWND hDlg,UINT uiMsg,WPARAM wParam,LPARAM lParam)
{
	UINT wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	switch (uiMsg) 
	{
	case WM_INITDIALOG:
#if(ANTIDEBUGACTIVE	== 1)
		AntiDebug();
#endif
		hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON));
		SendMessage(hDlg,WM_SETICON,TRUE,(WPARAM)hIcon);
		hwndTab=OnTabbedDialogInit(hDlg);
		hwndMain=hDlg;
		hwndDisplay=OnSelChanged(hDlg);
		hMenu=GetMenu(hDlg);
		hAccel=LoadAccelerators(hInst,MAKEINTRESOURCE(IDC_YC));
		/*hBitmap=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_OPEN));
		SendDlgItemMessage(hDlg,ID_FILE_OPEN,BM_SETIMAGE,
						   IMAGE_BITMAP,(WPARAM)hBitmap);
		hBitmap=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_SAVE));
		SendDlgItemMessage(hDlg,ID_FILE_SAVEAS,BM_SETIMAGE,
						   IMAGE_BITMAP,(WPARAM)hBitmap);

		hBitmap=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_PROTECT));
		SendDlgItemMessage(hDlg,ID_FILE_PROTECT,BM_SETIMAGE,
						   IMAGE_BITMAP,(WPARAM)hBitmap);

		hBitmap=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_HELP));
		SendDlgItemMessage(hDlg,ID_HELP_HELPCONTENTS,BM_SETIMAGE,
						   IMAGE_BITMAP,(WPARAM)hBitmap);*/
		break;   

	/*case WM_DROPFILES:
		hDrop=HDROP(wParam);
		DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
		DragFinish(hDrop);
		SetDlgItemText(hwndDisplay,IDC_FILE_OPEN,cFnameOpen);
		break;*/
 	   
	case WM_NOTIFY: 
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam);
		wmEvent=TCN_SELCHANGE;
		switch (wmEvent) 
		{ 
		case 0: 
			// menu command processing 
		
		case TCN_SELCHANGE: 
			int iPage = TabCtrl_GetCurSel(hwndTab); 
			LoadString(hInst,IDC_TABS + iPage, 
					g_achTemp,
					sizeof(g_achTemp)/sizeof(g_achTemp[0])); 
			hwndDisplay=OnSelChanged(hDlg);
			SendMessage(hwndDisplay, WM_SETTEXT, 0,
					(LPARAM) g_achTemp);
			break; 
		} 
		break; 

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case ID_FILE_OPEN:
			TabCtrl_SetCurSel(hwndTab,0);
			SendMessage(hwndMain,WM_NOTIFY,0x03f0,0);
			SendMessage(hwndDisplay,WM_COMMAND,ID_FILE_OPEN,0);
			break;

		case ID_FILE_SAVE:
			TabCtrl_SetCurSel(hwndTab,0);
			SendMessage(hwndMain,WM_NOTIFY,0x03f0,0);
			SendMessage(hwndDisplay,WM_COMMAND,ID_FILE_SAVE,0);
			break;

		case ID_FILE_PROTECT:
			SendMessage(hwndDisplay,WM_COMMAND,ID_FILE_PROTECT,0);
			break;

		case ID_OPTIONS_PROTECTION:
			TabCtrl_SetCurSel(hwndTab,1);
			SendMessage(hwndMain,WM_NOTIFY,0x03f0,0);
			break;

		case IDCLOSE:
			SendMessage(hDlg,WM_CLOSE,NULL,NULL);
			break;
              	                  
		case IDOK:
			EndDialog(hDlg,0);
			break;

		case ID_HELP_ABOUT:
			TabCtrl_SetCurSel(hwndTab,2);
			SendMessage(hwndMain,WM_NOTIFY,0x03f0,0);
			break;
		}
		break;

	case WM_PAINT:
		hdc = BeginPaint(hDlg, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hDlg, &ps);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	case WM_CLOSE:
		EndDialog(hDlg,0);
		break;
	}
	return 0;
}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}


