/* yS.cpp : Defines the entry point for the application.

   This file is part of the "yoda's Protector v1.0".

   Copyright (C) 2004-2005 Ashkbiz Danehkar
   All Rights Reserved.

   yoda's Protector v1.0 library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/

#include "stdafx.h"
#include "yP.h"
#include "TabCtrl.h"
#include "CryptStuff.h"
#include <commdlg.h>
#include <commctrl.h>
#include <shellapi.h>
#include <winuser.h>

char cFname[256];
char cFnameOpen[256];
char cFnameSave[256];

BOOL fStatus;
OPENFILENAME ofn;
char szCurDir[]=".";
char szFilter[]="EXE files (*.exe)|*.exe|All files (*.*)|*.*||";

DWORD CryptFlags;

bool CheckSI		= FALSE;
bool EraseHeader	= FALSE;
bool DestroyImport	= TRUE;
bool CheckHeader	= TRUE;
bool AntiDump		= TRUE;
bool ApiRedirect	= TRUE;
bool CompressRsrc	= FALSE;

HWND WINAPI OnTabbedDialogInit(HWND hwndDlg);
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName);
HWND WINAPI OnSelChanged(HWND hwndDlg);
VOID WINAPI OnChildDialogInit(HWND hwndDlg);
LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

#define C_PAGES 3
const LPSTR szTabName[C_PAGES]=
{
	"Open File",
	"Options",
	"About"
};
 typedef struct tag_dlghdr { 
    HWND hwndTab;       // tab control 
    HWND hwndDisplay;   // current child dialog box 
    RECT rcDisplay;     // display rectangle for the tab control 
    DLGTEMPLATE *apRes[C_PAGES]; 
} DLGHDR; 
DLGHDR *pHdr;


HWND WINAPI OnTabbedDialogInit(HWND hwndDlg) 
{ 
	RECT rcClient; 
    pHdr = (DLGHDR *) LocalAlloc(LPTR, sizeof(DLGHDR)); 
    TCITEM tie; 
    RECT rcTab; 
    int i; 
	// Save a pointer to the DLGHDR structure. 
    SetWindowLong(hwndDlg, GWL_USERDATA, (LONG) pHdr); 
	
	// Initialize the tab control.
	//InitCommonControls();
	pHdr->hwndTab = GetDlgItem(hwndDlg, IDC_TABS); 
	if (pHdr->hwndTab == NULL)// handle error 
	{
        return NULL;
    }
    // Determine the bounding rectangle for all child dialog boxes. 
	SetRectEmpty(&rcTab);
	GetClientRect(pHdr->hwndTab, &rcTab); 
	GetClientRect(hwndDlg, &rcClient); 
	rcTab.top=rcClient.bottom-rcTab.bottom+6;
	rcTab.left=4;
	rcTab.right=rcTab.right-3;
	rcTab.bottom=rcTab.top+rcTab.bottom-26;

	// Add a tab for each of the three child dialog boxes.
    tie.mask = TCIF_TEXT | TCIF_IMAGE; 
    tie.iImage = -1; 
    for (i=0;i<C_PAGES;i++) 
	{ 
        LoadString(hInst, IDC_TABS + i, 
                g_achTemp, sizeof(g_achTemp)/sizeof(g_achTemp[0])); 
		tie.pszText = szTabName[i]; 
        if(TabCtrl_InsertItem(pHdr->hwndTab, i, &tie)== -1) 
		{ 
            DestroyWindow(pHdr->hwndTab); 
            return NULL; 
		}
	} 

    // Lock the resources for the three child dialog boxes. 
    pHdr->apRes[0] = DoLockDlgRes(MAKEINTRESOURCE(DLG_OPEN));
    pHdr->apRes[1] = DoLockDlgRes(MAKEINTRESOURCE(DLG_PROTECTIONOPTIONS)); 
	pHdr->apRes[2] = DoLockDlgRes(MAKEINTRESOURCE(DLG_ABOUT)); 
	// Calculate the display rectangle. 
    CopyRect(&pHdr->rcDisplay, &rcTab); 

	// Simulate selection of the first item. 
    OnSelChanged(hwndDlg); 

    return pHdr->hwndTab; 
} 

// DoLockDlgRes - loads and locks a dialog template resource. 
// Returns a pointer to the locked resource. 
// lpszResName - name of the resource  
DLGTEMPLATE * WINAPI DoLockDlgRes(LPCSTR lpszResName) 
{ 
    HRSRC hrsrc = FindResource(NULL, lpszResName, RT_DIALOG); 
    HGLOBAL hglb = LoadResource(hInst, hrsrc); 

    return (DLGTEMPLATE *) LockResource(hglb); 
} 

// OnSelChanged - processes the TCN_SELCHANGE notification. 
// hwndDlg - handle to the parent dialog box. 
HWND WINAPI OnSelChanged(HWND hwndDlg) 
{ 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong(hwndDlg, GWL_USERDATA);
    int iSel = TabCtrl_GetCurSel(pHdr->hwndTab); 
 
    // Destroy the current child dial!og box, if any. 
    if (pHdr->hwndDisplay != NULL) 
        DestroyWindow(pHdr->hwndDisplay); 
 
    // Create the new child dialog box. 
	pHdr->hwndDisplay = CreateDialogIndirect(hInst, 
        pHdr->apRes[iSel], hwndDlg,(DLGPROC) ChildDialogProc);
	return(pHdr->hwndDisplay);
} 
 
// OnChildDialogInit - Positions the child dialog box to fall 
//     within the display area of the tab control. 
 VOID WINAPI OnChildDialogInit(HWND hwndDlg) 
{ 
    HWND hwndParent = GetParent(hwndDlg); 
    DLGHDR *pHdr = (DLGHDR *) GetWindowLong( 
        hwndParent, GWL_USERDATA); 
    SetWindowPos(hwndDlg, HWND_TOP, 
		pHdr->rcDisplay.left, 
		pHdr->rcDisplay.top, 
		pHdr->rcDisplay.right-pHdr->rcDisplay.left, 
		pHdr->rcDisplay.bottom-pHdr->rcDisplay.top, 
		SWP_DRAWFRAME); 
}

LRESULT CALLBACK ChildDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UINT wmId, wmEvent;
	switch (message)
	{
	case WM_INITDIALOG:
		OnChildDialogInit(hDlg);
		// check the checkboxes :)
		if(CheckSI)		 CheckDlgButton(hDlg,IDC_SICHECK,TRUE);
		if(EraseHeader)	 CheckDlgButton(hDlg,IDC_ERASEPEHEADER,TRUE);
		if(DestroyImport)CheckDlgButton(hDlg,IDC_DESTROYIMPORT,TRUE);
		if(CheckHeader)  CheckDlgButton(hDlg,IDC_CHECKHEADERCRC,TRUE);
		if(AntiDump)	 CheckDlgButton(hDlg,IDC_ANTIDUMP,TRUE);
		if(ApiRedirect)	 CheckDlgButton(hDlg,IDC_APIREDIRECT,TRUE);
		DragAcceptFiles(hDlg,TRUE);
		SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
		SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
		if(cFnameSave[0]!=0x00)
		{
			hButton=GetDlgItem(hDlg,ID_FILE_SAVE); 
			EnableWindow(hButton,TRUE);
			hButton=GetDlgItem(hDlg,ID_FILE_PROTECT); 
			EnableWindow(hButton,TRUE);
			hButton=GetDlgItem(hDlg,IDC_STATIC2); 
			EnableWindow(hButton,TRUE);
			UpdateWindow(hDlg); 
			EnableMenuItem(hMenu,ID_FILE_SAVE,MF_ENABLED);
			EnableMenuItem(hMenu,ID_FILE_PROTECT,MF_ENABLED);
			UpdateWindow(hwndMain);
		}
		return TRUE;

	case WM_DROPFILES:
		HDROP	hDrop;
		hDrop=HDROP(wParam);
		DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
		DragFinish(hDrop);
		SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
		strcpy(cFnameSave,cFnameOpen);
		SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
		SendMessage(hDlg, WM_INITDIALOG, 0, 0);
		break;

	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case ID_FILE_OPEN:
			// get a file path
			cFname[0]=0x00;
			ZeroMemory(&ofn, sizeof(ofn));
			ofn.hwndOwner=GetActiveWindow();
			ofn.lpstrFile=cFname;
			ofn.nMaxFile=sizeof(cFname);
			ofn.lStructSize=sizeof(ofn);
			ofn.lpstrFilter=TEXT("ExE files (*.exe)\0*.exe;All files (*.*)\0*.*\0\0");
			ofn.nFilterIndex = 1; 
			//ofn.lpstrInitialDir=szCurDir;
			ofn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			fStatus =GetOpenFileName(&ofn);//(LPOPENFILENAME
			if(!fStatus)
			{
				return 0;
			}
			strcpy(cFnameOpen,cFname);
			SetDlgItemText(hDlg,IDC_FILE_OPEN,cFnameOpen);
			strcpy(cFnameSave,cFnameOpen);
			SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
			SendMessage(hDlg, WM_INITDIALOG, 0, 0);
			break;

		case ID_FILE_SAVE:
			// get a file path
			cFnameSave[0]=0x00;
			strcpy(cFnameSave,cFnameOpen);
			ZeroMemory(&ofn, sizeof(ofn));
			ofn.hwndOwner=GetActiveWindow();
			ofn.lpstrFile=cFnameSave;
			ofn.nMaxFile=sizeof(cFnameSave);
			ofn.lStructSize=sizeof(ofn);
			ofn.lpstrFilter=TEXT("ExE files (*.exe)\0*.exe;All files (*.*)\0*.*\0\0");
			ofn.nFilterIndex = 1; 
			//ofn.lpstrInitialDir=szCurDir;
			ofn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			fStatus =GetSaveFileName(&ofn);//(LPOPENFILENAME
			if(!fStatus)
			{
				return 0;
			}
			SetDlgItemText(hDlg,IDC_FILE_SAVE,cFnameSave);
			break;

		case ID_FILE_PROTECT:
			// ----- was a file selected ? -----
			hwndProgress=GetDlgItem(hwndMain, IDC_PROGRESS1);
			if(cFnameOpen==NULL)
			{
				MessageBox(hDlg,"No file selected up to now !","ERROR",MB_ICONERROR);
				return 0;
			}
			if(cFnameSave==NULL)
			{
				MessageBox(hDlg,"No file selected up to save !","ERROR",MB_ICONERROR);
				return 0;
			}
			// ---- build the protection flag -----
			CryptFlags=0;
			//IsDlgButtonChecked(hDlg,IDC_APIREDIRECT)== BST_CHECKED
			if(CheckSI)		 CryptFlags=CryptFlags|CHECK_SI_FLAG;
			if(EraseHeader)	 CryptFlags=CryptFlags|ERASE_HEADER_FLAG;
			if(DestroyImport)CryptFlags=CryptFlags|DESTROY_IMPORT_FLAG;
			if(CheckHeader)  CryptFlags=CryptFlags|CHECK_HEADER_CRC;
			if(AntiDump)     CryptFlags=CryptFlags|ANTI_DUMP_FLAG;
			if(ApiRedirect)  CryptFlags=CryptFlags|API_REDIRECT_FLAG;
			if(CompressRsrc)  CryptFlags=CryptFlags|COMPRESS_RSRC_FLAG;
			CryptFile(cFnameOpen,cFnameSave,CryptFlags);
			break;

		case IDC_SICHECK:
			CheckSI=!CheckSI;
			break;

		case IDC_ERASEPEHEADER:
			EraseHeader=!EraseHeader;
			break;

		case IDC_DESTROYIMPORT:
			DestroyImport=!DestroyImport;
			break;

		case IDC_ANTIDUMP:
			AntiDump=!AntiDump;
			break;

		case IDC_APIREDIRECT:
			ApiRedirect=!ApiRedirect;
			break;

		case IDC_CHECKHEADERCRC:
			CheckHeader=!CheckHeader;
			break;

		}
		break;

	}
	return FALSE;
}
